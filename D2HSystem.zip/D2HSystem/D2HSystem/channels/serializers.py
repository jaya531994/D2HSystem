from rest_framework import serializers
from channels.models import ChannelListModel

class ChannelListSerializer(serializers.ModelSerializer):
    class Meta:
        model = ChannelListModel
        fields = '__all__'