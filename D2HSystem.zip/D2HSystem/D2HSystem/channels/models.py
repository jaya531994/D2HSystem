from statistics import mode
from tkinter import CASCADE
from django.db import models

class LanguageModel(models.Model):
    name = models.CharField(max_length=10)

    class Meta:
        verbose_name = 'Language'
        
    def __str__(self):
         return self.name

class ChannelTypeModel(models.Model):
    type = models.CharField(max_length=10)
    class Meta:
        verbose_name = 'Channel Type'

    def __str__(self):
         return self.type

class ChannelListModel(models.Model):
    channel_number = models.IntegerField(unique=True)
    channel_name = models.CharField(max_length=10)
    channel_price = models.CharField(max_length=10)
    channel_description = models.TextField()
    channel_image = models.ImageField()
    channel_language = models.ForeignKey(LanguageModel, on_delete=models.CASCADE)
    channel_type = models.ForeignKey(ChannelTypeModel, on_delete=models.CASCADE)
    channel_created = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = 'Channel'

    def __str__(self):
         return self.channel_name
    
