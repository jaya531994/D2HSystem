from rest_framework import generics
from channels.serializers import ChannelListSerializer
from channels.models import ChannelListModel

class ChannelListView(generics.ListCreateAPIView):
    queryset = ChannelListModel.objects.all()
    serializer_class = ChannelListSerializer

class UpdateChannelView(generics.RetrieveUpdateAPIView):
    queryset = ChannelListModel.objects.all()
    serializer_class = ChannelListSerializer