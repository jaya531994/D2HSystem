from django.contrib import admin
from .models import LanguageModel,ChannelTypeModel,ChannelListModel

# Register your models here.
admin.site.register(LanguageModel)
admin.site.register(ChannelTypeModel)

class ChannelListAdmin(admin.ModelAdmin):
    list_display = ('channel_number', 'channel_name', 'channel_price')

admin.site.register(ChannelListModel,ChannelListAdmin)
