from django.urls import path
from rest_framework.urlpatterns import format_suffix_patterns
from channels import views

urlpatterns = [
    path('channels/', views.ChannelListView.as_view()),
    path('update_channel/<int:pk>/', views.UpdateChannelView.as_view()),
]

urlpatterns = format_suffix_patterns(urlpatterns)