from rest_framework import serializers
from packages.models import Package

class PackageListSerializer(serializers.ModelSerializer):
    class Meta:
        model = Package
        fields = '__all__'