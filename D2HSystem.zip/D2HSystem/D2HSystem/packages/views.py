from django.shortcuts import render
from rest_framework import generics
from packages.serializers import PackageListSerializer
from packages.models import Package

class PackageListView(generics.ListAPIView):
    queryset = Package.objects.all()
    serializer_class = PackageListSerializer

