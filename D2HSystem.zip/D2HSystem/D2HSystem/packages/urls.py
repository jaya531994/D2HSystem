from django.urls import path
from rest_framework.urlpatterns import format_suffix_patterns
from packages import views

urlpatterns = [
    path('package/', views.PackageListView.as_view()),
]

urlpatterns = format_suffix_patterns(urlpatterns)