from django.db import models

# Create your models here.
class Package(models.Model):
    pakage_name = models.CharField(max_length=100)
    package_price = models.CharField(max_length=10)
    number_of_channel = models.IntegerField()
    SD_channel = models.BooleanField()
    HD_channel = models.BooleanField()

    # class Meta:
    #     db_table = 'Package'
        
